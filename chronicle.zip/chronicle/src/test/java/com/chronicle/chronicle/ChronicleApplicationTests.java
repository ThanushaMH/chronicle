package com.chronicle.chronicle;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChronicleApplicationTests {

	@Test
	void contextLoads() {
	}

}
