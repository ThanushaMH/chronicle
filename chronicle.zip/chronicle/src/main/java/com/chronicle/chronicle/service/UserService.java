package com.chronicle.chronicle.service;

import com.chronicle.chronicle.dto.UserDTO;
import com.chronicle.chronicle.entity.User;
import com.chronicle.chronicle.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    public UserDTO getUserDetailsByUsername(String username) {
        User user = userRepository.findByUsername(username)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Map user to UserDTO
        return new UserDTO(
                user.getUsername(),
                user.getFirstName(),
                user.getLastName(),
                user.getEmail(),
                user.getContactNumber()
        );
    }
    public List<String> getAllUsernames() {
        List<User> users = userRepository.findAllUsernames();
        return users.stream().map(User::getUsername).toList();
    }

    public List<String> getAllEmails() {
        List<User> users = userRepository.findAllEmails();
        return users.stream().map(User::getEmail).toList();
    }
}

