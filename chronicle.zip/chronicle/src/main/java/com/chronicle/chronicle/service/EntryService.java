package com.chronicle.chronicle.service;

import com.chronicle.chronicle.dto.*;
import com.chronicle.chronicle.entity.Entry;
import com.chronicle.chronicle.entity.File;
import com.chronicle.chronicle.entity.User;
import com.chronicle.chronicle.repository.EntryRepository;
import com.chronicle.chronicle.repository.FileRepository;
import com.chronicle.chronicle.repository.UserRepository;
import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class EntryService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private EntryRepository entryRepository;

    @Autowired
    private FileRepository fileRepository;

    public void createEntry(EntryRequestDTO request) {
        // Find user by username
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Create and save new entry
        Entry entry = new Entry();
        entry.setUserId(user.getUserId());
        entry.setEntryId(new ObjectId());
        entry.setContent(request.getContent());
        entry.setTitle(request.getTitle());
        entry.setCreatedDate(new Date());
        entry.setModifiedDate(new Date());

        Entry savedEntry = entryRepository.save(entry);

        // Create and save files if media array is not empty
        if (request.getMedia() != null && !request.getMedia().isEmpty()) {
            List<File> files = request.getMedia().stream().map(media -> {
                File file = new File();
                file.setEntryId(savedEntry.getEntryId());
                file.setFileId(new ObjectId());
                file.setFileName(media);
                file.setUploadedDate(new Date());
                file.setModifiedDate(new Date());
                return file;
            }).collect(Collectors.toList());

            fileRepository.saveAll(files);
        }
    }

    public List<EntryResponseDTO> findEntriesByUsernameAndTitle(EntryQueryDTO query) {
        // Step 1: Find user by username
        User user = userRepository.findByUsername(query.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Step 2: Find entries matching userId and title
        List<Entry> entries = entryRepository.findAllByUserIdAndTitle(user.getUserId(), query.getTitle());
        if (entries.isEmpty()) {
            throw new RuntimeException("No entries found with the given title for the user");
        }

        // Step 3: Prepare the response
        List<EntryResponseDTO> response = new ArrayList<>();
        for (Entry entry : entries) {
            // Fetch matching files
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            List<File> files = fileRepository.findAllByEntryId(entry.getEntryId());
            List<String> fileNames = files.stream()
                    .map(File::getFileName)
                    .collect(Collectors.toList());

            // Populate response DTO
            EntryResponseDTO dto = new EntryResponseDTO();
            dto.setTitle(entry.getTitle());
            dto.setContent(entry.getContent());
            dto.setCreatedDate(dateFormat.format(entry.getCreatedDate()));
            dto.setMedia(fileNames);

            response.add(dto);
        }

        return response;
    }
    @Transactional
    public void updateEntry(UpdateEntryDTO request) {
        // Step 1: Fetch user by username
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Step 2: Fetch the matching entry by userId and title
        Entry entry = entryRepository.findAllByUserIdAndTitle(user.getUserId(), request.getTitle())
                .stream()
                .findFirst()
                .orElseThrow(() -> new RuntimeException("No entry found with the given title for the user"));

        // Step 3: Fetch files matching the entryId
        List<File> existingFiles = fileRepository.findAllByEntryId(entry.getEntryId());
        List<String> existingFileNames = existingFiles.stream()
                .map(File::getFileName)
                .collect(Collectors.toList());

        // Step 4: Identify files to delete and delete them
        List<String> mediaFromRequest = request.getMedia();
        List<File> filesToDelete = existingFiles.stream()
                .filter(file -> !mediaFromRequest.contains(file.getFileName()))
                .collect(Collectors.toList());

        if (!filesToDelete.isEmpty()) {
            fileRepository.deleteAll(filesToDelete);
        }

        // Step 5: Identify new media files to add and add them
        List<String> newMedia = mediaFromRequest.stream()
                .filter(media -> !existingFileNames.contains(media))
                .collect(Collectors.toList());

        List<File> newFiles = newMedia.stream()
                .map(media -> {
                    File file = new File();
                    file.setEntryId(entry.getEntryId());
                    file.setFileId(new ObjectId());
                    file.setFileName(media);
                    file.setUploadedDate(new Date());
                    file.setModifiedDate(new Date());
                    return file;
                })
                .collect(Collectors.toList());

        if (!newFiles.isEmpty()) {
            fileRepository.saveAll(newFiles);
        }

        // Step 6: Update entry content and modifiedDate
        entry.setContent(request.getContent());
        entry.setModifiedDate(new Date());
        entryRepository.save(entry);
    }

    @Transactional
    public void deleteEntryAndFiles(DeleteEntryDTO request) {
        // Step 1: Fetch the user by username
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Step 2: Fetch entries by userId and title
        List<Entry> entries = entryRepository.findAllByUserIdAndTitle(user.getUserId(), request.getTitle());
        if (entries.isEmpty()) {
            throw new RuntimeException("No entries found with the given title for the user");
        }

        // Step 3: Delete associated files for each entry
        for (Entry entry : entries) {
            fileRepository.deleteAllByEntryId(entry.getEntryId());
        }

        // Step 4: Delete entries matching userId and title
        entryRepository.deleteAllByUserIdAndTitle(user.getUserId(), request.getTitle());
    }

    public List<String> fetchTitlesByUsername(FetchTitlesDTO request) {
        // Step 1: Fetch the user by username
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Step 2: Fetch entries by userId
        List<Entry> entries = entryRepository.findAllByUserId(user.getUserId());

        // Step 3: Extract and return the titles
        return entries.stream()
                .map(Entry::getTitle)
                .collect(Collectors.toList());
    }

    public List<String> fetchCreatedDatesByUsername(FetchDatesDTO request) {
        // Step 1: Fetch the user by username
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        // Step 2: Fetch entries by userId
        List<Entry> entries = entryRepository.findAllByUserId(user.getUserId());

        // Step 3: Format the createdDate to "yyyy-MM-dd"
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        return entries.stream()
                .map(entry -> dateFormat.format(entry.getCreatedDate()))
                .collect(Collectors.toList());
    }

    public List<String> fetchEntries(EntryFilterDTO request) {
        // Step 1: Fetch the user by username
        User user = userRepository.findByUsername(request.getUsername())
                .orElseThrow(() -> new RuntimeException("User not found"));

        ObjectId userId = user.getUserId();

        // Step 2: Handle different cases
        if (request.getTitle() == null && request.getCreatedDate() == null) {
            // Case 1: Only username provided
            return entryRepository.findAllByUserIdOrderByCreatedDateDesc(userId)
                    .stream()
                    .map(Entry::getTitle)
                    .collect(Collectors.toList());
        } else if (request.getTitle() != null) {
            // Case 2: Username and title provided
            return entryRepository.findAllByUserIdAndTitle(userId, request.getTitle())
                    .stream()
                    .map(Entry::getTitle)
                    .collect(Collectors.toList());
        } else if (request.getCreatedDate() != null) {
            // Case 3: Username and createdDate provided

            // Parse the createdDate input
            LocalDate inputDate = LocalDate.parse(request.getCreatedDate());

            // Calculate the start and end of the day
            Date startOfDay = Date.from(inputDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
            Date endOfDay = Date.from(inputDate.plusDays(1).atStartOfDay(ZoneId.systemDefault()).toInstant());

            // Query using the calculated date range
            return entryRepository.findAllByUserIdAndCreatedDateRange(userId, startOfDay, endOfDay)
                    .stream()
                    .map(Entry::getTitle)
                    .collect(Collectors.toList());
        } else {
            throw new IllegalArgumentException("Invalid combination of inputs.");
        }
    }
}

