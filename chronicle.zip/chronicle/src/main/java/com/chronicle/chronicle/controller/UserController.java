package com.chronicle.chronicle.controller;

import com.chronicle.chronicle.dto.UserDTO;
import com.chronicle.chronicle.service.UserService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Base64;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins = "*")
public class UserController {
    @Autowired
    private UserService userService;

    @PostMapping("/details")
    public ResponseEntity<String> getUserDetails(@RequestBody String encodedRequest) {
        try {
            // Decode the Base64 encoded request payload
            byte[] decodedBytes = Base64.getDecoder().decode(encodedRequest);
            String decodedRequest = new String(decodedBytes);

            // Parse the JSON payload
            Map<String, String> requestMap = new ObjectMapper().readValue(decodedRequest, Map.class);
            String username = requestMap.get("username");

            if (username == null || username.isEmpty()) {
                return ResponseEntity.badRequest().build();
            }

            // Fetch user details
            UserDTO userDetails = userService.getUserDetailsByUsername(username);

            // Convert the response to JSON and encode it as Base64
            String jsonResponse = new ObjectMapper().writeValueAsString(userDetails);
            String encodedResponse = Base64.getEncoder().encodeToString(jsonResponse.getBytes());

            return ResponseEntity.ok(encodedResponse);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).build();
        }
    }
    @GetMapping("/usernames")
    public ResponseEntity<Map<String, Object>> getAllUsernames() {
        try {
            // Retrieve the list of usernames
            List<String> usernames = userService.getAllUsernames();

            // Create the response object
            Map<String, Object> response = new HashMap<>();
            response.put("usernames", usernames);

            // Convert the response to a JSON string
            String jsonString = new ObjectMapper().writeValueAsString(response);

            // Encode the JSON string using Base64
            String encodedJson = Base64.getEncoder().encodeToString(jsonString.getBytes());

            // Return the encoded JSON in the response
            Map<String, Object> encodedResponse = new HashMap<>();
            encodedResponse.put("encodedData", encodedJson);

            return ResponseEntity.ok(encodedResponse);
        } catch (JsonProcessingException e) {
            // Handle JSON processing exception
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "Failed to encode JSON");
            return ResponseEntity.status(500).body(errorResponse);
        }
    }

    @GetMapping("/emails")
    public ResponseEntity<Map<String, Object>> getAllEmails() {
        try {
            List<String> emails = userService.getAllEmails();
            Map<String, Object> response = new HashMap<>();
            response.put("emails", emails);

            // Convert the JSON object to a String
            String jsonString = new ObjectMapper().writeValueAsString(response);

            // Encode the JSON String using Base64
            String encodedJson = Base64.getEncoder().encodeToString(jsonString.getBytes());

            // Return the encoded JSON as the response
            Map<String, Object> encodedResponse = new HashMap<>();
            encodedResponse.put("encodedData", encodedJson);

            return ResponseEntity.ok(encodedResponse);
        } catch (JsonProcessingException e) {
            // Handle the exception and return a meaningful response
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "Failed to process JSON");
            return ResponseEntity.status(500).body(errorResponse);
        }
    }
}

