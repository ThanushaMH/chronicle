package com.chronicle.chronicle.repository;

import com.chronicle.chronicle.entity.Entry;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

import java.util.List;

@Repository
public interface EntryRepository extends MongoRepository<Entry, ObjectId> {
    List<Entry> findAllByUserIdAndTitle(ObjectId userId, String title);
    void deleteAllByUserIdAndTitle(ObjectId userId, String title);
    List<Entry> findAllByUserId(ObjectId userId);
    List<Entry> findAllByUserIdOrderByCreatedDateDesc(ObjectId userId);
    @Query("{'userId': ?0, 'createdDate': {$gte: ?1, $lt: ?2}}")
    List<Entry> findAllByUserIdAndCreatedDateRange(ObjectId userId, Date startDate, Date endDate);

}
