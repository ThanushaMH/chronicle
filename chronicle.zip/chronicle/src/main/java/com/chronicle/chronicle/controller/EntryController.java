package com.chronicle.chronicle.controller;

import com.chronicle.chronicle.dto.*;
import com.chronicle.chronicle.service.EntryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@CrossOrigin(origins="*")
@RestController
@RequestMapping("/api/entries")
public class EntryController {
    @Autowired
    private EntryService entryService;

    @PostMapping("/create")
    public ResponseEntity<String> createEntry(@RequestBody EntryRequestDTO request) {
        try {
            entryService.createEntry(request);
            return ResponseEntity.ok("Entry and files created successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error: " + e.getMessage());
        }
    }

    @PostMapping("/search")
    public ResponseEntity<List<EntryResponseDTO>> searchEntries(@RequestBody EntryQueryDTO query) {
        try {
            List<EntryResponseDTO> results = entryService.findEntriesByUsernameAndTitle(query);
            return ResponseEntity.ok(results);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(Collections.emptyList());
        }
    }

    @PutMapping("/update")
    public ResponseEntity<String> updateEntry(@RequestBody UpdateEntryDTO request) {
        try {
            entryService.updateEntry(request);
            return ResponseEntity.ok("Entry and files updated successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error: " + e.getMessage());
        }
    }

    @DeleteMapping("/delete")
    public ResponseEntity<String> deleteEntryAndFiles(@RequestBody DeleteEntryDTO request) {
        try {
            entryService.deleteEntryAndFiles(request);
            return ResponseEntity.ok("Entries and associated files deleted successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("Error: " + e.getMessage());
        }
    }

    @PostMapping("/titles")
    public ResponseEntity<List<String>> fetchTitlesByUsername(@RequestBody FetchTitlesDTO request) {
        try {
            List<String> titles = entryService.fetchTitlesByUsername(request);
            return ResponseEntity.ok(titles);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.singletonList("Error: " + e.getMessage()));
        }
    }

    @PostMapping("/created-date")
    public ResponseEntity<List<String>> fetchCreatedDatesByUsername(@RequestBody FetchDatesDTO request) {
        try {
            List<String> createdDates = entryService.fetchCreatedDatesByUsername(request);
            return ResponseEntity.ok(createdDates);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Collections.singletonList("Error: " + e.getMessage()));
        }
    }

    @PostMapping("/filter")
    public ResponseEntity<Map<String, Object>> filterEntries(@RequestBody EntryFilterDTO request) {
        try {
            List<String> title = entryService.fetchEntries(request);
            // Wrap the response in a JSON object
            Map<String, Object> response = new HashMap<>();
            response.put("title", title);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            // Wrap the error response in a JSON object
            Map<String, Object> errorResponse = new HashMap<>();
            errorResponse.put("error", "Error: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(errorResponse);
        }
    }

}
