package com.chronicle.chronicle.dto;

public class FetchDatesDTO {
    private String username;

    // Getters and Setters

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}

