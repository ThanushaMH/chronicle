package com.chronicle.chronicle.repository;

import com.chronicle.chronicle.entity.File;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface FileRepository extends MongoRepository<File, ObjectId> {
    List<File> findAllByEntryId(ObjectId entryId);
    void deleteAllByEntryId(ObjectId entryId);

}